



import java.io.*;
import java.net.*;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;

public class Servidor {

    private static  int port = 3145;
    private ServerSocket serverSocket;
    private Socket clientSocket1;
    private Socket clientSocket2;
    private PrintWriter out1;
    private PrintWriter out2;
    private BufferedReader in1;
    private BufferedReader in2;
    private PublicKey publicKey; // Clave pública del servidor
    private PrivateKey privateKey; // Clave privada del servidor
    private Cipher rsa;

    public void start(int port) {
        try {
            // Generar el par de claves (clave pública y privada) del servidor o cargarlas si ya existen
            if (!loadKeys()) {
                KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
                KeyPair keyPair = keyPairGenerator.generateKeyPair();
                publicKey = keyPair.getPublic();
                privateKey = keyPair.getPrivate();
                saveKeys();
            }

            // Iniciar el servidor
            serverSocket = new ServerSocket(port);
            System.out.println("Servidor iniciado en el puerto " + port);

            clientSocket1 = serverSocket.accept();
            System.out.println("Cliente 1 conectado: " + clientSocket1);
            clientSocket2 = serverSocket.accept();
            System.out.println("Cliente 2 conectado: " + clientSocket2);

            out1 = new PrintWriter(clientSocket1.getOutputStream(), true);
            in1 = new BufferedReader(new InputStreamReader(clientSocket1.getInputStream()));
            out2 = new PrintWriter(clientSocket2.getOutputStream(), true);
            in2 = new BufferedReader(new InputStreamReader(clientSocket2.getInputStream()));

            // Obtener la clase para encriptar/desencriptar con RSA
            rsa = Cipher.getInstance("RSA/ECB/PKCS1Padding");

            new Thread(() -> comunicacionesCliente(in1, out2)).start();
            new Thread(() -> comunicacionesCliente(in2, out1)).start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void comunicacionesCliente(BufferedReader in, PrintWriter out) {
        try {
            String mensajeCliente;
            while ((mensajeCliente = in.readLine()) != null) {
                System.out.println("Mensaje recibido: " + mensajeCliente);

                // Desencriptar el mensaje utilizando la clave privada del servidor
                byte[] mensajeEncriptado = hexStringToByteArray(mensajeCliente);
                rsa.init(Cipher.DECRYPT_MODE, privateKey);
                byte[] mensajeDesencriptado = rsa.doFinal(mensajeEncriptado);
                String mensajeOriginal = new String(mensajeDesencriptado);

                System.out.println("Mensaje desencriptado: " + mensajeOriginal);

                // Enviar una respuesta (puedes encriptarla si lo deseas)
                out.println("Servidor: " + mensajeOriginal);

                if (mensajeOriginal.equalsIgnoreCase("chau")) {
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean loadKeys() {
        try {
            FileInputStream publicKeyFile = new FileInputStream("publickey.dat");
            byte[] publicKeyBytes = new byte[publicKeyFile.available()];
            publicKeyFile.read(publicKeyBytes);
            publicKeyFile.close();

            FileInputStream privateKeyFile = new FileInputStream("privatekey.dat");
            byte[] privateKeyBytes = new byte[privateKeyFile.available()];
            privateKeyFile.read(privateKeyBytes);
            privateKeyFile.close();

            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyBytes);
            publicKey = keyFactory.generatePublic(publicKeySpec);

            PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(privateKeyBytes);
            privateKey = keyFactory.generatePrivate(privateKeySpec);

            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void saveKeys() {
        try {
            byte[] publicKeyBytes = publicKey.getEncoded();
            FileOutputStream publicKeyFile = new FileOutputStream("publickey.dat");
            publicKeyFile.write(publicKeyBytes);
            publicKeyFile.close();

            byte[] privateKeyBytes = privateKey.getEncoded();
            FileOutputStream privateKeyFile = new FileOutputStream("privatekey.dat");
            privateKeyFile.write(privateKeyBytes);
            privateKeyFile.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        Servidor servidor = new Servidor();
        servidor.start(port);
    }

    // Función para convertir una cadena hexadecimal a un arreglo de bytes
    private static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                    + Character.digit(s.charAt(i + 1), 16));
        }
        return data;
    }
}