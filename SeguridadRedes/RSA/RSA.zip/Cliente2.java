
import java.io.*;
import java.net.*;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;

public class Cliente2 {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private BufferedReader stdIn;
    private PublicKey publicKeyServidor; // Clave pública del servidor
    private Cipher rsa;

    public void start(String host, int port) {
        try {
            socket = new Socket(host, port);
            System.out.println("Conectado al servidor: " + socket);

            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            stdIn = new BufferedReader(new InputStreamReader(System.in));

            // Obtener la clave pública del servidor (puedes cargarla desde un archivo)
            loadPublicKey();

            // Obtener la clase para encriptar con RSA
            rsa = Cipher.getInstance("RSA/ECB/PKCS1Padding");

            new Thread(() -> leerRespuestasServer()).start();

            String entradaUsuario;
            while ((entradaUsuario = stdIn.readLine()) != null) {
                System.out.println("Mensaje enviado: " + entradaUsuario); 
                // Encriptar el mensaje con la clave pública del servidor antes de enviarlo
                rsa.init(Cipher.ENCRYPT_MODE, publicKeyServidor);
                byte[] mensajeEncriptado = rsa.doFinal(entradaUsuario.getBytes());
                String mensajeEncriptadoHex = byteArrayToHexString(mensajeEncriptado);

                out.println(mensajeEncriptadoHex);
                if (entradaUsuario.equalsIgnoreCase("chau")) {
                    break;
                }
            }

            in.close();
            out.close();
            socket.close();
            System.out.println("Desconectado del servidor");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void leerRespuestasServer() {
        try {
            String respuestaServidor;
            while ((respuestaServidor = in.readLine()) != null) {
                System.out.println("Respuesta del servidor: " + respuestaServidor);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadPublicKey() throws Exception {
        FileInputStream publicKeyFile = new FileInputStream("publickey.dat");
        byte[] publicKeyBytes = new byte[publicKeyFile.available()];
        publicKeyFile.read(publicKeyBytes);
        publicKeyFile.close();

        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyBytes);
        publicKeyServidor = keyFactory.generatePublic(publicKeySpec);
    }

    public static void main(String[] args) {
        String host = "localhost";
        int port = 3145;
        Cliente2 cliente2 = new Cliente2();
        cliente2.start(host, port);
    }

    // funcion para convertir un arreglo de bytes a una cadena hexadecimal
    private static String byteArrayToHexString(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}