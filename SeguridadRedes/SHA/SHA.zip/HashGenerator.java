import java.security.MessageDigest;
import java.util.Scanner;

public class HashGenerator {
    public static String generateHash(String algorithm, String data) throws Exception {
        MessageDigest md = MessageDigest.getInstance(algorithm);
        byte[] hashBytes = md.digest(data.getBytes("UTF-8"));
        StringBuilder hash = new StringBuilder();
        for (byte b : hashBytes) {
            hash.append(String.format("%02x", b));
        }
        return hash.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int x = 0;

        while (x < 1) {
            System.out.println("Elige el número del algoritmo a usar:");
            System.out.println("1 - SHA256");
            System.out.println("3 - Acabar programa");

            int nAlgoritmo = scanner.nextInt();
            scanner.nextLine(); // Consumir la nueva línea después del entero

            if (nAlgoritmo == 1) {
                try {
                    System.out.println("Introduce datos a hashear:");
                    String datos = scanner.nextLine();

                    String algoritmo = "SHA-256";
                    String hash1 = generateHash(algoritmo, datos);

                    System.out.println();
                    System.out.println(hash1);
                    System.out.println();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (nAlgoritmo == 3) {
                x = 1;
                System.out.println("FIN. ");
            } else {
                x = 1;
                System.out.println("Opción no válida.");
            }
        }
    }
}
